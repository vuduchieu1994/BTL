<div class="container-fluid" id="main">
        <div class="row row-offcanvas row-offcanvas-left">
            <div class="col-md-3 col-lg-2 sidebar-offcanvas bg-light pl-0" id="sidebar" role="navigation">
                <ul class="nav flex-column sticky-top pl-0 pt-5 mt-3">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Thống kê</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Danh sách khóa học</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Thêm khóa học</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Danh sách sinh viên</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Thêm sinh viên</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Đăng thông báo</a>
                    </li>
                </ul>
            </div>